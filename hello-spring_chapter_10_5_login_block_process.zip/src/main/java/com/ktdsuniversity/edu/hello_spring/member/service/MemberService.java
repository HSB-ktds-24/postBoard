package com.ktdsuniversity.edu.hello_spring.member.service;

import com.ktdsuniversity.edu.hello_spring.member.vo.LoginMemberVO;
import com.ktdsuniversity.edu.hello_spring.member.vo.MemberVO;
import com.ktdsuniversity.edu.hello_spring.member.vo.MemberWriteVO;

public interface MemberService {

	public boolean createNewMember(MemberWriteVO memberWriteVO);
	
	public boolean checkAvailableEamil(String email);
	
	public MemberVO readMember(LoginMemberVO loginMemberVO);
	
	public boolean deleteMe(String email);
}
