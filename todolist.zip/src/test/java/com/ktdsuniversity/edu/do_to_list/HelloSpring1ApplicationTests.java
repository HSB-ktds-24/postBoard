package com.ktdsuniversity.edu.do_to_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
