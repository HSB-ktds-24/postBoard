package com.ktdsuniversity.edu.do_to_list.bbs.vo;

public class ScheduleWriteVO {

	private String subject;	
	private String deadline;
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDeadline() {
		return deadline;
	}
	public void setDeadline(String deadline) {
		this.deadline = deadline;
	}

	
}
