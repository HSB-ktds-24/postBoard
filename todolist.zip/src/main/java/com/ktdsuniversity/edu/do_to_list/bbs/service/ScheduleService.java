package com.ktdsuniversity.edu.do_to_list.bbs.service;

import java.util.List;

import com.ktdsuniversity.edu.do_to_list.bbs.vo.ScheduleVO;
import com.ktdsuniversity.edu.do_to_list.bbs.vo.ScheduleWriteVO;

public interface ScheduleService {

	public boolean createSchedule(ScheduleWriteVO scheduleWriteVO);
	public boolean removeSchedule(int id);
	public boolean updateState(int id);
	public List<ScheduleVO> showAllSchedule();
	
	
}
